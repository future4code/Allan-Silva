// 1. funcao nomeada sem parametro e sem retorno

// 2. funcao nomeada sem parametro e sem retorno, dentro do for

// 3. funcao nomeada com parametro e sem retorno

// 4. funcao nomeada com parametro e com retorno

